const firebaseConfig = {
    apiKey: "AIzaSyCGc_3Rc12wsKoc03XZPvJ5_oo2iEwbeFw",
    authDomain: "accounting-erp-2674e.firebaseapp.com",
    projectId: "accounting-erp-2674e",
    storageBucket: "accounting-erp-2674e.appspot.com",
    messagingSenderId: "23066561245",
    appId: "1:23066561245:web:4cd58180bf5200477fe934"
};

export default firebaseConfig;