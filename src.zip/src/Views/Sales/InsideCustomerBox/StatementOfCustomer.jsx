import React from 'react'

const StatementOfCustomer = () => {
  return (
    <>
      StatementOfCustomer
    </>
  )
}

export default StatementOfCustomer
