import React from 'react'

const CustomerDetailsBlock = () => {
  return (
    <div>
      pending

      not used yet
    </div>
  )
}

export default CustomerDetailsBlock
