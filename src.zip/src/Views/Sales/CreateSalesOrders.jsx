import React from 'react'

const CreateSalesOrders = () => {
  return (
    <>
      create sales order
    </>
  )
}

export default CreateSalesOrders



