import React, { useEffect, useState } from 'react';
import TopLoadbar from '../../../Components/Toploadbar/TopLoadbar';
import { RxCross2 } from 'react-icons/rx';
import { Link } from 'react-router-dom';
import DisableEnterSubmitForm from '../../Helper/DisableKeys/DisableEnterSubmitForm';
import { useDispatch, useSelector } from 'react-redux';
import { updateQuotation } from '../../../Redux/Actions/quotationActions';
import { customersList } from '../../../Redux/Actions/customerActions';
import CustomDropdown10 from '../../../Components/CustomDropdown/CustomDropdown10';
import CustomDropdown11 from '../../../Components/CustomDropdown/CustomDropdown11';
import { itemLists } from '../../../Redux/Actions/listApisActions';

const CreateQuotation = () => {
    const dispatch = useDispatch();
    const cusList = useSelector((state) => state?.customerList);
    const itemList = useSelector((state) => state?.itemList);
    const [cusData, setcusData] = useState(null)
    const [itemData, setItemData] = useState({
        price: 0,
        purchase_price: 0,
        tax_rate: 0,
        // Other default values as needed
    }); const [viewAllCusDetails, setViewAllCusDetails] = useState(false)
    // console.log("itemListitemList", itemList);
    console.log("itemData", itemData);



    const [formData, setFormData] = useState({
        sale_type: 'quotation',
        transaction_date: '',
        warehouse_id: localStorage.getItem('warehouse_id') || '',
        quotation_id: 'QT-20212',
        customer_id: '',
        customer_type: null,
        customer_name: null,
        phone: null,
        email: null,
        address: null,
        currency: 'INR',
        place_of_supply: 'kanpur',
        expiry_date: '',
        sale_person: 'xyz',
        project_name: 'boxes',
        customer_note: null,
        terms: null,
        fy: localStorage.getItem('fy') || 2024,
        subtotal: 0,
        shipping_charge: 0,
        adjustment_charge: 0,
        total: 0,
        items: [],
    });
    console.log("formdata", formData)
    const [loading, setLoading] = useState(false);
    const handleItemAdd = () => {
        const newItems = [...formData.items, {
            item_id: '',
            quantity: 1,
            gross_amount: 0,
            final_amount: 0,
            tax_rate: (+(itemData?.tax_rate)),
            tax_amount: 0,
            discount: 0,
            discount_type: 1,
            item_remark: null,
        }];
        setFormData({ ...formData, items: newItems });
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    }

    const handleItemChange = (index, field, value) => {
        const newItems = [...formData.items];
        newItems[index][field] = value;


        if (field === 'quantity' || field === 'gross_amount' || field === 'tax_rate') {
            const item = newItems[index];
            item.final_amount = item.quantity * item.gross_amount;
            item.tax_amount = item.quantity * item.gross_amount * (item.tax_rate / 100);
        }
        setFormData({ ...formData, items: newItems });



        setFormData({ ...formData, items: newItems });

    };


    //for set data of items when I select the itmes
    useEffect(() => {
        if (itemData) {
            const updatedItems = formData.items.map(item => ({
                ...item,
                gross_amount: (+itemData?.price) || 0,
                tax_rate: (+itemData?.tax_rate) || 0,
            }));
            setFormData({ ...formData, items: updatedItems });
        }
    }, [itemData]);


    const handleFormSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await dispatch(updateQuotation(formData));
            setLoading(false);
        } catch (error) {
            console.error('Error updating quotation:', error);
            setLoading(false);
        }
    };

    //for set the data when select the customer
    useEffect(() => {
        setFormData({
            ...formData,
            customer_type: cusData?.customer_type,
            customer_name: cusData ? `${cusData.first_name} ${cusData.last_name}` : '',
            email: cusData?.email,
            phone: cusData?.mobile_no,
            address: cusData?.address.length
        })
    }, [cusData])


    // fetch lists data's
    useEffect(() => {
        dispatch(customersList({ fy: "2024" }));
        dispatch(itemLists({ fy: "2024" }));

    }, [dispatch])
    // fetch lists data's

    return (
        <>
            <TopLoadbar />
            <div id="Anotherbox" className='formsectionx1'>
                <div id="leftareax12">
                    <h1 id="firstheading">
                        {/* <img src={"/assets/Icons/allcustomers.svg"} alt="" /> */}
                        <svg id="fi_2110601" enable-background="new 0 0 64 64" height="512" viewBox="0 0 64 64" width="512" xmlns="http://www.w3.org/2000/svg"><g fill="#555c61"><path d="m21 25h4v15h-4z"></path><path d="m30 32h4v8h-4z"></path><path d="m39 26h4v14h-4z"></path></g><path d="m30.959 52.975c-.706-.034-1.417-.105-2.115-.21l.298-1.979c.631.096 1.276.159 1.915.19zm2.124-.002-.101-1.998c.642-.032 1.286-.097 1.913-.193l.304 1.977c-.695.105-1.407.178-2.116.214zm-6.322-.631c-.678-.174-1.361-.387-2.029-.633l.689-1.877c.606.223 1.224.415 1.837.572zm10.52-.013-.5-1.936c.615-.159 1.232-.354 1.834-.576l.695 1.875c-.665.247-1.348.461-2.029.637zm-14.506-1.459c-.63-.309-1.256-.655-1.859-1.03l1.056-1.699c.546.34 1.112.653 1.683.933zm18.488-.018-.882-1.795c.572-.281 1.138-.597 1.679-.936l1.062 1.695c-.6.375-1.225.724-1.859 1.036zm-22.094-2.227c-.56-.432-1.103-.897-1.615-1.383l1.376-1.451c.463.439.955.86 1.461 1.252zm25.695-.025-1.227-1.58c.506-.393.997-.814 1.46-1.255l1.378 1.449c-.51.486-1.053.952-1.611 1.386zm-28.777-2.896c-.462-.537-.902-1.102-1.306-1.679l1.64-1.146c.365.522.762 1.033 1.181 1.519zm31.854-.032-1.52-1.301c.419-.489.815-1.001 1.179-1.523l1.641 1.145c-.401.574-.838 1.14-1.3 1.679zm-34.288-3.448c-.345-.618-.662-1.26-.941-1.906l1.836-.793c.252.585.539 1.165.851 1.725zm36.715-.036-1.749-.971c.312-.562.597-1.144.848-1.728l1.838.789c-.277.646-.593 1.288-.937 1.91zm-38.398-3.863c-.212-.674-.393-1.366-.536-2.059l1.959-.404c.129.626.292 1.253.484 1.861zm40.073-.043-1.909-.596c.191-.612.353-1.239.481-1.863l1.959.4c-.141.691-.32 1.383-.531 2.059zm-40.933-4.116c-.072-.7-.109-1.414-.111-2.122l2-.004c.001.642.035 1.287.1 1.921zm41.784-.044-1.99-.201c.064-.632.096-1.278.096-1.921l1.39-.057.61.039c0 .727-.036 1.441-.106 2.14zm-39.802-4.003-1.99-.197c.069-.702.175-1.409.314-2.101l1.961.395c-.127.627-.222 1.266-.285 1.903zm37.804-.12c-.066-.637-.166-1.275-.296-1.899l1.958-.408c.144.689.254 1.396.328 2.101zm-37.043-3.647-1.91-.594c.208-.669.455-1.34.733-1.996l1.841.783c-.252.594-.476 1.202-.664 1.807zm36.258-.113c-.193-.607-.42-1.214-.675-1.801l1.835-.797c.282.649.533 1.32.747 1.992zm-34.75-3.421-1.75-.967c.342-.619.719-1.227 1.122-1.807l1.643 1.141c-.364.525-.705 1.075-1.015 1.633zm33.22-.102c-.31-.554-.654-1.102-1.024-1.629l1.637-1.148c.409.582.79 1.188 1.133 1.799zm-31.029-3.055-1.521-1.299c.459-.538.951-1.058 1.461-1.545l1.382 1.445c-.461.442-.906.913-1.322 1.399zm28.82-.089c-.417-.482-.865-.95-1.331-1.39l1.373-1.455c.515.486 1.009 1.003 1.471 1.536zm-26.042-2.568-1.229-1.578c.555-.432 1.14-.843 1.739-1.22l1.065 1.693c-.542.342-1.072.713-1.575 1.105zm23.248-.07c-.508-.391-1.041-.759-1.583-1.096l1.054-1.699c.599.371 1.187.778 1.748 1.209zm-19.994-1.973-.888-1.793c.631-.312 1.288-.597 1.952-.845l.7 1.873c-.6.225-1.194.482-1.764.765zm16.726-.053c-.573-.278-1.168-.532-1.77-.753l.688-1.877c.665.243 1.323.523 1.957.833zm-13.127-1.292-.507-1.936c.684-.179 1.384-.324 2.083-.432l.305 1.977c-.631.098-1.264.229-1.881.391zm9.521-.03c-.622-.157-1.256-.285-1.885-.378l.293-1.979c.696.103 1.397.244 2.084.419zm-5.726-.56-.104-1.998c.374-.02.739-.026 1.13-.028.332 0 .664.008.994.023l-.093 1.998c-.315-.014-.629-.015-.952-.021-.329 0-.653.009-.975.026z" fill="#eb4f53"></path><path d="m23.583 4.167-8.166-1.167.797 2.39c-7.373 4.004-12.654 11.194-14.197 19.425l1.966.369c1.411-7.527 6.187-14.12 12.872-17.87l.895 2.686z" fill="#5eb2d0"></path><path d="m7.534 47.536 2.466-.822-5.714-5.714-1.143 8 2.458-.819c4.033 7.171 11.118 12.29 19.216 13.803l.367-1.967c-7.391-1.38-13.875-5.998-17.65-12.481z" fill="#5eb2d0"></path><path d="m61.983 39.185-1.966-.369c-1.389 7.4-6.022 13.896-12.521 17.673l-.829-2.489-5.833 5.833 8.166 1.167-.86-2.58c7.186-4.036 12.322-11.13 13.843-19.235z" fill="#529bb5"></path><path d="m58.421 15.86c-4.025-7.182-11.12-12.318-19.236-13.842l-.369 1.965c7.411 1.393 13.907 6.026 17.675 12.521l-2.348.783 5.714 5.713 1.143-8z" fill="#5eb2d0"></path></svg>
                        New Quotation
                    </h1>
                </div>
                <div id="buttonsdata">
                    <Link to={"/dashboard/quotation"} className="linkx3">
                        <RxCross2 />
                    </Link>
                </div>
            </div>

            <div id="formofcreateitems">
                <DisableEnterSubmitForm onSubmit={handleFormSubmit}>
                    <div className="itemsformwrap">
                        <div>
                            <label>Sale Type:</label>
                            <input
                                type="text"
                                value={formData.sale_type}
                                disabled
                            />
                        </div>
                        <div>
                            <label>Transaction Date:</label>
                            <input
                                type="date"
                                value={formData.transaction_date}
                                onChange={handleChange}
                                name='transaction_date'
                                required
                            />
                        </div>
                        <div>
                            <label>Warehouse ID:</label>
                            <input
                                type="text"
                                value={formData.warehouse_id}
                                disabled
                            />
                        </div>
                        <div>
                            <label>Quotation ID:</label>
                            <input
                                type="text"
                                value={formData.quotation_id}
                                disabled
                            />
                        </div>
                        <div className="form-group">
                            <label >Customer ID</label>
                            <span >
                                <CustomDropdown10
                                    label="Customer Name"
                                    options={cusList?.data?.user}
                                    value={formData.customer_id}
                                    onChange={handleChange}
                                    name="customer_id"
                                    defaultOption="Select Customer"
                                    setcusData={setcusData}
                                />
                            </span>

                            {!cusData ? "" :
                                <>
                                    <div className="showCustomerDetails">

                                        <div className="cus_fewDetails">
                                            <label >Customer full Name :  {cusData?.first_name + " " + cusData?.last_name}</label>
                                            <br></br>
                                            <label >Email :  {cusData?.email}</label>
                                            {viewAllCusDetails &&
                                                <>
                                                    <br></br>
                                                    <label >Company Name :  {cusData?.company_name}</label>
                                                    <br></br>
                                                    <label >Customer type :  {cusData?.customer_type}</label>
                                                    <br></br>
                                                    <label >Mobile no :  {cusData?.mobile_no}</label>
                                                    <label >Place Of Supply :  {cusData?.place_of_supply}</label>
                                                </>
                                            }
                                        </div>

                                    </div>
                                    <div className="view_all_cus_deial_btn">
                                        {viewAllCusDetails === true ?
                                            <button type="button" onClick={() => setViewAllCusDetails(false)}>Hide Details</button>
                                            :
                                            <button type="button" onClick={() => setViewAllCusDetails(true)}>View all Details</button>

                                        }
                                    </div>
                                </>
                            }

                        </div>
                        <div>
                            <label>Customer Type:</label>
                            <input
                                type="text"
                                value={formData.customer_type}
                                onChange={(e) => setFormData({ ...formData, customer_type: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Customer Name:</label>
                            <input
                                type="text"
                                value={formData.customer_name}
                                onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Phone:</label>
                            <input
                                type="text"
                                value={formData.phone}
                                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Email:</label>
                            <input
                                type="email"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Address:</label>
                            <input
                                type="text"
                                value={formData.address}
                                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Currency:</label>
                            <input
                                type="text"
                                value={formData.currency}
                                onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Place of Supply:</label>
                            <input
                                type="text"
                                value={formData.place_of_supply}
                                onChange={(e) => setFormData({ ...formData, place_of_supply: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Expiry Date:</label>
                            <input
                                type="date"
                                value={formData.expiry_date}
                                onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Sales Person:</label>
                            <input
                                type="text"
                                value={formData.sale_person}
                                onChange={(e) => setFormData({ ...formData, sale_person: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Project Name:</label>
                            <input
                                type="text"
                                value={formData.project_name}
                                onChange={(e) => setFormData({ ...formData, project_name: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Customer Note:</label>
                            <textarea
                                value={formData.customer_note}
                                onChange={(e) => setFormData({ ...formData, customer_note: e.target.value })}
                            />
                        </div>
                        <div>
                            <label>Terms:</label>
                            <input
                                type="text"
                                value={formData.terms}
                                onChange={(e) => setFormData({ ...formData, terms: e.target.value })}
                            />
                        </div>
                        <div>
                            <label>FY:</label>
                            <input
                                type="text"
                                value={formData.fy}
                                disabled
                            />
                        </div>
                        <div>
                            <label>Subtotal:</label>
                            <input
                                type="text"
                                value={formData.subtotal}
                                disabled
                            />
                        </div>
                        <div>
                            <label>Shipping Charge:</label>
                            <input
                                type="number"
                                value={formData.shipping_charge}
                                onChange={(e) => setFormData({ ...formData, shipping_charge: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Adjustment Charge:</label>
                            <input
                                type="number"
                                value={formData.adjustment_charge}
                                onChange={(e) => setFormData({ ...formData, adjustment_charge: e.target.value })}
                                required
                            />
                        </div>
                        <div>
                            <label>Total:</label>
                            <input
                                type="text"
                                value={formData.total}
                                disabled
                            />
                        </div>
                        {formData.items.map((item, index) => (
                            <div key={index}>
                                <label>Item ID:</label>
                                <input
                                    type="text"
                                    value={item.item_id}
                                    onChange={(e) => handleItemChange(index, 'item_id', e.target.value)}
                                    required
                                />
                                <div className="form-group">
                                    <label >Item ID</label>
                                    <span >
                                        <CustomDropdown11
                                            label="Item Name"
                                            options={itemList?.data?.item}
                                            value={item.item_id}
                                            onChange={(e) => handleItemChange(index, 'item_id', e.target.value)}
                                            name="item_id"
                                            defaultOption="Select Items"
                                            setItemData={setItemData}
                                        />
                                    </span>
                                </div>
                                <label>Quantity:</label>
                                <input
                                    type="number"
                                    value={item.quantity}
                                    onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                                    required
                                />
                                <label>Gross Amount:</label>
                                <input
                                    type="number"
                                    value={item.gross_amount}
                                    onChange={(e) => handleItemChange(index, 'gross_amount', e.target.value)}
                                    required
                                />
                                <label>Final Amount:</label>
                                <input
                                    type="number"
                                    value={item.final_amount}
                                    onChange={(e) => handleItemChange(index, 'final_amount', e.target.value)}
                                    required
                                />
                                <label>Tax Rate:</label>
                                <input
                                    type="number"
                                    value={item.tax_rate}
                                    onChange={(e) => handleItemChange(index, 'tax_rate', e.target.value)}
                                    required
                                />
                                <label>Tax Amount:</label>
                                <input
                                    type="number"
                                    value={item.tax_amount}
                                    onChange={(e) => handleItemChange(index, 'tax_amount', e.target.value)}
                                    required
                                />
                                <label>Discount:</label>
                                <input
                                    type="number"
                                    value={item.discount}
                                    onChange={(e) => handleItemChange(index, 'discount', e.target.value)}
                                    required
                                />
                                <label>Discount Type:</label>
                                <select
                                    value={item.discount_type}
                                    onChange={(e) => handleItemChange(index, 'discount_type', e.target.value)}
                                >
                                    <option value={1}>Currency (INR)</option>
                                    <option value={2}>Percentage (%)</option>
                                </select>
                                <label>Item Remark:</label>
                                <textarea
                                    value={item.item_remark}
                                    onChange={(e) => handleItemChange(index, 'item_remark', e.target.value)}
                                />
                            </div>
                        ))}
                        <button type="button" onClick={handleItemAdd}>Add Item</button>
                        <button type="submit" disabled={loading}>
                            {loading ? 'Updating...' : 'Update'}
                        </button>
                    </div>
                </DisableEnterSubmitForm>
            </div>
        </>
    );
};

export default CreateQuotation;
